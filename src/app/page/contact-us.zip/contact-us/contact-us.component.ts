import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-us',
  standalone: true,
  imports: [HttpClientModule],
  templateUrl: './contact-us.component.html',
  styleUrl: './contact-us.component.css'
})
export class ContactUsComponent {

  constructor(private http: HttpClient) { }

  onSubmit(contactForm: any) {
    const formData = contactForm.value;
    // Send form data to the backend 
    this.http.post('http://localhost:3000/send-email', formData).subscribe((response) => {
      console.log('Email sent successfully', response);
    },
      (error) => {
        console.error('Error sending email', error);
      });
  }
}


